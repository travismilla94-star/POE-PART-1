Place supporting documents here, such as the compressed ZIP of researched
content (text, images, other assets) referenced in the Website Project Proposal,
and any wireframes or planning documents.
