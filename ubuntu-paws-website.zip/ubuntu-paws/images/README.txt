Place sourced images here (e.g. hero photos, animal photos, logo).
Every image must be your own, properly licensed, or in the public domain.
Cite the source of every non-original image in README.md under References,
using the Harvard style referencing guide adapted for the IIE.
